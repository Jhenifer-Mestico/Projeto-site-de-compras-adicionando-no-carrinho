var nome = alert("Oba! Seja bem vindo(a)!!!");

window.onload = function () { 
    exibirMenu();
};

var xml;

function exibirMenu() {
    carregarXML();

    opcoes = xml.getElementsByTagName("opcao");             

    const menu = document.getElementById('menu');

    for (i = 0; i < opcoes.length; i++) {      
        menu.innerHTML += '<a href="' + opcoes[i].getAttribute("link") + '">' + opcoes[i].firstChild.nodeValue +  '</a> <br>';
    }
}

function carregarXML() {

        var xmlHttp = new XMLHttpRequest();
        xmlHttp.open("GET", "menu/menu.xml", false);
        xmlHttp.send(null);
        xml = xmlHttp.responseXML;
    }

var prod = []
var valores = []

    $(function(){
    mostrarCompras();
});

function mostrarCompras() {
    $.getJSON("funcao/compras.json", function(data){          
        quant = data.produtos.length;
        for (var i = 0; i < quant; i++)
        {
            prod[i]= data.produtos[i].Prato
            valores[i]= data.produtos[i].valor   
            var Div=`<div class=card> <div class="rest">${data.produtos[i].Restaurante}</div><p>${data.produtos[i].Prato}</p><p> ${data.produtos[i].valor}</p><button value="button" onclick="gravarDados(${[i]})">Adicionar</button></div>`;
           $("#compras").append(Div);
        }
        adicionarCarrinho(); 
    });   
}

function gravarDados(x){
    sessionStorage.setItem((prod[x]),(valores[x])); 
    alert("Prato: "+prod[x]+" adicionado com sucesso!");
}

function adicionarCarrinho(){
    
    if (sessionStorage.length >0) {
        var total = 0;
        for(var i = 0; i < prod.length; i++) {
            var conteudo = sessionStorage.getItem(prod[i]);
            if (conteudo!= null){
                var resultado =`<tr><td>${prod[i]}</td><td>R$${conteudo}</td></tr>`
                $("#produtos").append(resultado) 
                total = total+parseFloat(conteudo)
            }   
        }
    var y = `<tr><td><b>TOTAL</b></td><td>R$${total.toFixed(2)}</td></tr>`
    $("#produtos").append(y)
    }
    
}

function limparCarrinho() {
    sessionStorage.clear();
    $("#produtos td").remove();
    $("#produtos").append(`<tr><td> Aaah! Seu carrinho está vazio!</td><td> </td></tr>`)
    $("#produtos").append(`<td><b>TOTAL:</b></td><td><b>R$0.00</b></td>`)
}